============
LAB 1 README
============
* Oct 1, 2017
* This lab assignment was completed in equal partnership by Laura Petrich
* and Nicholas Mayne in the class CMPUT 399 Fa17, at the University of Alberta.
*
* Everything contained in this submission is our original work.
* Sources have been cited.
-------------------------------------------------------------------------------

/	---
	README
	the Lab1.pdf report

/code	---
	aggressive 	// Braitenberg vehicle with 'aggressive' behaviour

	Command		// represents a command object that is used by a Robot
			// see class for available commands to use as a parameter
			// for the drive() thread in Robot

	explore		// Braitenberg vehicle with 'exploring' behaviour

	cowardice	// Braitenberg vehicle with 'cowardice' behaviour

	j_rect		// Program used in the drawing of the rectangles
	j_line		// Program used in the drawing of the lines
	j_circle	// Program used in the drawing of the circles
	j_8		// Program used in the drawing of the figure-eights

	love		// Braitenberg vehicle with 'love' behaviour

	RemoteControl	// the remote to control the robot, must be tried until
			// it connects to the robot server (clunky, will improve
			// this in the future)

***	Robot		// main method and static classes for driving, localizing, 				// sensing, and teleoperation. Comment or uncomment the
			// lines:	localize.start();
			//		sensorData.start();
			//		commandInput.start();
			//		drive.start();
			// to enable or disable a particular functionality thread.


/images---
	photographs of our robot embodiments
	photographs of the figure drawings with measurements
	Photograph of measuring technique for Part 4


/videos	---
	videos of the braitenberg vehicle behaviours
		- agression
		- cowardice
		- explore
		- love
	Video of teleoperation
	
